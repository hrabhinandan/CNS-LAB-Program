import java.io.*;
import java.net.*;
import java.util.Scanner;
class UDPServer
{
	public static void main(String args[])throws Exception
	{
		DatagramSocket ServerSocket=new DatagramSocket(9876);
		System.out.println("Server started on port 9876");
		byte[]receiveData=new byte[1024];
		byte[]sendData=new byte[1024];
		DatagramPacket receivePacket=new DatagramPacket(receiveData,receiveData.length);
		ServerSocket.receive(receivePacket);
		receivePacket.getData();
		InetAddress IPAddress=receivePacket.getAddress();
		int port=receivePacket.getPort();
		System.out.println("client connected");
		Scanner input=new Scanner(System.in);
		System.out.println("enter the message to be sent");
		String message=input.nextLine();
		sendData=message.getBytes();
		DatagramPacket sendPacket=new DatagramPacket(sendData,sendData.length,IPAddress,port);
		ServerSocket.send(sendPacket);
		System.exit(0);
	}
}
