import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
public class TCPServer
{
	public static void main(String args[])throws Exception
	{
		ServerSocket SerSock=new ServerSocket(4000);
		System.out.println("Server ready for connection");
		Socket Sock=SerSock.accept();
		System.out.println("connection successful|waiting for file name");
		InputStream istream=Sock.getInputStream();
		BufferedReader br=new BufferedReader(new InputStreamReader(istream));
		String fname=br.readLine();
		BufferedReader contentRead=new BufferedReader(new FileReader(fname));
		OutputStream ostream=Sock.getOutputStream();
		PrintWriter pwrite=new PrintWriter(ostream,true);
		String str;
		while((str=contentRead.readLine())!=null)
		{
			pwrite.println(str);
		}
		System.out.println("file content sent successfully");
		Sock.close(); SerSock.close();
		pwrite.close();br.close();contentRead.close();
	}
}
