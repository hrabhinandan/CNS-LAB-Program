import java.util.Scanner;
import java.io.*;
public class crc
{
	public static void main(String args[])
	{
		Scanner Sc=new Scanner(System.in);
		System.out.print("enter message bits:");
		String message=Sc.nextLine();
		System.out.println("enter generator:");
		String generator=Sc.nextLine();
		int data[]=new int[message.length()+generator.length()-1];
		int divisor[]=new int[generator.length()];
		for(int i=0;i<message.length();i++)
			data[i]=Integer.parseInt(message.charAt(i)+"");
		for(int i=0;i<generator.length();i++)
			divisor[i]=Integer.parseInt(generator.charAt(i)+"");
		for(int i=0;i<message.length();i++)
		{
			if(data[i]==1)
				for(int j=0;j<divisor.length;j++)
					data[i+j]^=divisor[j];
		}
		System.out.print("the checksumcode is:");
		for(int i=0;i<message.length();i++)
			data[i]=Integer.parseInt(message.charAt(i)+"");
		for(int i=0;i<data.length;i++)
			System.out.print(data[i]);
		        System.out.println();
				System.out.print("enter checksumcode is:");
				message=Sc.nextLine();
				System.out.print("enter generator:");
				generator=Sc.nextLine();
				data=new int[message.length()+generator.length()-1];
				divisor=new int[generator.length()];
				for(int i=0;i<message.length();i++)
					data[i]=Integer.parseInt(message.charAt(i)+"");
				for(int i=0;i<generator.length();i++)
					divisor[i]=Integer.parseInt(generator.charAt(i)+"");
				for(int i=0;i<message.length();i++)
				{
					if(data[i]==1)
						for(int j=0;j<divisor.length;j++)
							data[i+j]^=divisor[j];
				}
                         
				boolean valid=true;
				for(int i=0;i<data.length;i++)
					if(data[i]==1){
						valid=false;
			                	break;
                               }		
	
	if(valid==true)
		System.out.println("Data stream is valid");
	else
        
	
		System.out.println("Data stream  invalid crc error occured");
                
}	
	}
				

