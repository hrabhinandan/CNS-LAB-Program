import java.util.Scanner;
public class leakyBucket{

	public static void main(String args[]) throws InterruptedException
	{

	 
	       int n,outgoing,incoming,store=0,Bucketsize;
		Scanner Scan=new Scanner(System.in);
		System.out.println("enter the Bucketsize,outgoing rate,number of inputs,incoming size");
		Bucketsize=Scan.nextInt();
		outgoing=Scan.nextInt();
		n=Scan.nextInt();
		incoming=Scan.nextInt();
		while(n!=0)
		{
			System.out.println("incoming size"+incoming);
			if(incoming<=(Bucketsize=store))
			{
				store+=incoming;
				System.out.println("Bucket buffer size"+store+"out of"+Bucketsize);
			}
			else
			{
				System.out.println("packetloss:"+(incoming-(Bucketsize=store)));
				store=Bucketsize;
					System.out.println("Bucket buffer size"+store+"out of"+Bucketsize);
			}
			store=outgoing;
			System.out.println("after outgoing:"+store+"packets left out of"+Bucketsize);
			n--;
			Thread.sleep(3000);
		}
		Scan.close();
	}
}




